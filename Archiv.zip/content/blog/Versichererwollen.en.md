+++
date = "2017-05-20T12:24:34+02:00"
title = "Insurers want to be like Amazon"
type = "blog"
author = "FAZ vom 17.08.2016 Seite 23"
banner = "/img/blog/2400x1600.jpg"

+++

(...)

 If the job went to Jobst Landgrebe, the insurers would have to be much faster. The founder and owner of Cognotekt relies on artificial intelligence as an efficient player. For many years the entrepreneur worked in the insurance industry and realized that many damages are so similar that they can be automated well. For a service provider in the car insurance, he has built a vending machine, which looks at cost estimates or bills from workshops, whether they are objectionable. He has documented a six-digit number of old documents. The machine then categorizes new documents. If it does not resemble a pattern or pattern that has been questionable in the past, the document is sent to the manual check. For a healthcare provider, Cognotekt has built a vending machine that detects whether the language matches the invoiced services.
 Landgrebe is good in business, has increased its sales tenfold within two years. But the insurance industry is still not working properly. Apparently, she fears that many places might be superfluous when Artificial Intelligence comes through. "Managers of insurers are different from thinking. They are conservative and change-makers, "says Landgrebe. Too few companies use the chances of making claims processing more efficient. "By using a simple machine, half of all tests can be eliminated," he says.

(...)