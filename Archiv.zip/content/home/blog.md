+++
title = "blog"
description = "Blog"
type = "section/blog"
tags = [ "Cognotekt", "Blog" ]
date = "2017-05-20"
weight = 7
categories = [
  "Blog",
  "Cognotekt"
]
+++
Content of the file goes Here
