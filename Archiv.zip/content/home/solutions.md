+++
title = "solutions"
description = "Lösungen"
type = "section/solutions"
tags = [ "Cognotekt", "Lösungen" ]
date = "2017-04-26"
weight = 3
categories = [
  "Lösungen",
  "Cognotekt"
]
+++
Content of the file goes Here
