+++
title = "wwd.en"
description = "what we do"
type = "section/wwd"
tags = [ "Cognotekt", "What We Do" ]
date = "2017-04-26"
weight = 2
categories = [
  "What We Do",
  "Cognotekt"
]
+++
Content of the file goes Here
