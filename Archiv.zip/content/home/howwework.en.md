+++
title = "howwework.en"
description = "how we work"
type = "section/howwework"
tags = [ "Cognotekt", "how we work", "work" ]
date = "2017-04-26"
weight = 4
categories = [
  "how we work",
  "Cognotekt"
]
+++
Content of the file goes Here
