+++
title = "solutions.en"
description = "solutions"
type = "section/solutions"
tags = [ "Cognotekt", "solutions" ]
date = "2017-04-26"
weight = 3
categories = [
  "solutions",
  "Cognotekt"
]
+++
Content of the file goes Here
